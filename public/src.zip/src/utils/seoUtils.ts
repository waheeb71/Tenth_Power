// SEO Utilities for enhanced search engine optimization

export const generateMetaKeywords = (profileData: any): string[] => {
  const keywords = [
    // Personal name variations
    profileData.fullName,
    profileData.fullName.replace(/\s+/g, ''),
    
    // Professional titles
    profileData.title,
    'خبير أمن سيبراني',
    'مطور برمجيات',
    'Cybersecurity Expert',
    'Software Developer',
    
    // Skills and technologies
    ...profileData.programmingLanguages,
    ...profileData.cybersecurityTools,
    ...profileData.backendWeb,
    
    // Location-based keywords
    'اليمن',
    'تعز',
    'Yemen',
    'Taiz',
    'الجامعة الوطنية تعز',
    'National University Taiz',
    
    // Industry keywords
    'اختبار الاختراق',
    'أمن الشبكات',
    'الاختراق الأخلاقي',
    'Penetration Testing',
    'Network Security',
    'Ethical Hacking',
    'Vulnerability Assessment',
    'Security Audit',
    
    // Project-related keywords
    'مشاريع البرمجة',
    'تطوير التطبيقات',
    'Programming Projects',
    'Application Development',
    
    // Education keywords
    'هندسة الحاسوب',
    'علوم الحاسوب',
    'Computer Engineering',
    'Computer Science',
    
    // Certification keywords
    'شهادات مهنية',
    'Professional Certifications',
    'CEH',
    'CompTIA Security+',
    
    // Long-tail keywords
    'خبير أمن سيبراني في اليمن',
    'مطور برمجيات تعز',
    'اختبار الاختراق الأخلاقي',
    'Cybersecurity expert Yemen',
    'Software developer Taiz',
    'Ethical hacking specialist'
  ];
  
  return [...new Set(keywords)]; // Remove duplicates
};

export const generateStructuredDataForAI = (profileData: any) => {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": profileData.fullName,
    "jobTitle": profileData.title,
    "description": profileData.summary,
    "url": window.location.origin,
    "email": profileData.email,
    "telephone": profileData.phone,
    "address": {
      "@type": "PostalAddress",
      "addressLocality": profileData.location,
      "addressCountry": "Yemen"
    },
    "nationality": {
      "@type": "Country",
      "name": "Yemen"
    },
    "knowsLanguage": profileData.languages.map((lang: any) => ({
      "@type": "Language",
      "name": lang.name,
      "proficiencyLevel": lang.level
    })),
    "hasOccupation": {
      "@type": "Occupation",
      "name": profileData.title,
      "occupationLocation": {
        "@type": "Place",
        "name": profileData.location
      },
      "skills": [
        ...profileData.programmingLanguages,
        ...profileData.cybersecurityTools,
        ...profileData.backendWeb
      ].join(", "),
      "responsibilities": profileData.experience[0]?.description || []
    },
    "alumniOf": profileData.education.map((edu: any) => ({
      "@type": "EducationalOrganization",
      "name": edu.institution,
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "تعز",
        "addressCountry": "Yemen"
      }
    })),
    "hasCredential": profileData.certifications.map((cert: any) => ({
      "@type": "EducationalOccupationalCredential",
      "name": cert.title,
      "credentialCategory": "certification",
      "recognizedBy": {
        "@type": "Organization",
        "name": cert.institution
      },
      "dateCreated": cert.date,
      "credentialId": cert.credentialId
    })),
    "workExample": profileData.projects.map((project: any) => ({
      "@type": "CreativeWork",
      "name": project.title,
      "description": project.description,
      "creator": {
        "@type": "Person",
        "name": profileData.fullName
      },
      "programmingLanguage": project.technologies,
      "url": project.githubUrl || project.liveUrl,
      "dateCreated": "2024",
      "genre": "Software Development",
      "inLanguage": ["ar", "en"]
    })),
    "sameAs": [
      profileData.github,
      profileData.linkedin,
      profileData.telegram,
      ...(profileData.instagram ? [profileData.instagram] : []),
      ...(profileData.twitter ? [profileData.twitter] : [])
    ],
    "knowsAbout": [
      // Technical skills
      ...profileData.programmingLanguages,
      ...profileData.cybersecurityTools,
      ...profileData.backendWeb,
      ...profileData.cloudDevOps,
      ...profileData.networking,
      ...profileData.ai,
      
      // Domain expertise
      "Cybersecurity",
      "Information Security",
      "Penetration Testing",
      "Vulnerability Assessment",
      "Network Security",
      "Ethical Hacking",
      "Security Auditing",
      "Risk Assessment",
      "Incident Response",
      "Security Architecture",
      "Compliance",
      "OWASP",
      "ISO 27001",
      "NIST Framework",
      
      // Programming concepts
      "Software Development",
      "Web Development",
      "API Development",
      "Database Design",
      "System Administration",
      "DevOps",
      "Cloud Computing",
      "Machine Learning",
      "Artificial Intelligence"
    ],
    "seeks": {
      "@type": "Demand",
      "name": "Cybersecurity Opportunities",
      "description": "Seeking challenging cybersecurity roles and software development projects"
    }
  };
};

export const injectStructuredData = (data: any) => {
  // Remove existing structured data
  const existingScript = document.querySelector('#structured-data-ld-json');
  if (existingScript) {
    existingScript.remove();
  }
  
  // Create new structured data script
  const script = document.createElement('script');
  script.id = 'structured-data-ld-json';
  script.type = 'application/ld+json';
  script.textContent = JSON.stringify(data, null, 2);
  document.head.appendChild(script);
};

export const updatePageMeta = (profileData: any, locale: string) => {
  const title = `${profileData.fullName} - ${profileData.title} | CV Portfolio`;
  const description = profileData.seo.metaDescription;
  const keywords = generateMetaKeywords(profileData).join(', ');
  
  // Update title
  document.title = title;
  
  // Update meta description
  let metaDesc = document.querySelector('meta[name="description"]') as HTMLMetaElement;
  if (metaDesc) {
    metaDesc.content = description;
  }
  
  // Update meta keywords
  let metaKeywords = document.querySelector('meta[name="keywords"]') as HTMLMetaElement;
  if (metaKeywords) {
    metaKeywords.content = keywords;
  }
  
  // Update Open Graph tags
  const updateOGTag = (property: string, content: string) => {
    let tag = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
    if (tag) {
      tag.content = content;
    }
  };
  
  updateOGTag('og:title', title);
  updateOGTag('og:description', description);
  updateOGTag('og:url', window.location.href);
  
  // Update Twitter Card tags
  const updateTwitterTag = (name: string, content: string) => {
    let tag = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
    if (tag) {
      tag.content = content;
    }
  };
  
  updateTwitterTag('twitter:title', title);
  updateTwitterTag('twitter:description', description);
  
  // Update structured data
  const structuredData = generateStructuredDataForAI(profileData);
  injectStructuredData(structuredData);
};

// AI-friendly content extraction
export const generateAIReadableContent = (profileData: any): string => {
  return `
PERSON: ${profileData.fullName}
TITLE: ${profileData.title}
LOCATION: ${profileData.location}
EMAIL: ${profileData.email}
PHONE: ${profileData.phone}

SUMMARY: ${profileData.summary}

PROGRAMMING_LANGUAGES: ${profileData.programmingLanguages.join(', ')}
CYBERSECURITY_TOOLS: ${profileData.cybersecurityTools.join(', ')}
DATABASES: ${profileData.databases.join(', ')}
BACKEND_WEB: ${profileData.backendWeb.join(', ')}
CLOUD_DEVOPS: ${profileData.cloudDevOps.join(', ')}
NETWORKING: ${profileData.networking.join(', ')}
AI_SKILLS: ${profileData.ai.join(', ')}

EXPERIENCE:
${profileData.experience.map((exp: any, index: number) => `
${index + 1}. ${exp.title} (${exp.date})
   Company: ${exp.company || 'N/A'}
   Responsibilities:
   ${exp.description.map((desc: string) => `   - ${desc}`).join('\n')}
`).join('\n')}

EDUCATION:
${profileData.education.map((edu: any, index: number) => `
${index + 1}. ${edu.degree}
   Institution: ${edu.institution}
   Date: ${edu.date}
   GPA: ${edu.gpa || 'N/A'}
`).join('\n')}

CERTIFICATIONS:
${profileData.certifications.map((cert: any, index: number) => `
${index + 1}. ${cert.title}
   Institution: ${cert.institution}
   Date: ${cert.date}
   Credential ID: ${cert.credentialId || 'N/A'}
`).join('\n')}

PROJECTS:
${profileData.projects.map((project: any, index: number) => `
${index + 1}. ${project.title}
   Status: ${project.status}
   Duration: ${project.duration}
   Team Size: ${project.teamSize}
   Technologies: ${project.technologies.join(', ')}
   Description: ${project.description}
   GitHub: ${project.githubUrl || 'N/A'}
   Live URL: ${project.liveUrl || 'N/A'}
`).join('\n')}

SOCIAL_LINKS:
GitHub: ${profileData.github}
LinkedIn: ${profileData.linkedin}
Telegram: ${profileData.telegram}
Instagram: ${profileData.instagram || 'N/A'}
Twitter: ${profileData.twitter || 'N/A'}

LANGUAGES:
${profileData.languages.map((lang: any) => `${lang.name}: ${lang.level}`).join('\n')}

SOFT_SKILLS: ${profileData.softSkills.join(', ')}
  `.trim();
};