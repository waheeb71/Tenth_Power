import { useEffect } from 'react';
import { ProfileData } from '../data/profileData';
import { updatePageMeta, generateAIReadableContent } from '../utils/seoUtils';

export const useSEO = (profileData: ProfileData, locale: string) => {
  useEffect(() => {
    if (profileData) {
      // Update all meta tags and structured data
      updatePageMeta(profileData, locale);
      
      // Add AI-readable content as hidden text for better AI understanding
      let aiContent = document.querySelector('#ai-readable-content');
      if (!aiContent) {
        aiContent = document.createElement('div');
        aiContent.id = 'ai-readable-content';
        aiContent.style.display = 'none';
        aiContent.setAttribute('aria-hidden', 'true');
        document.body.appendChild(aiContent);
      }
      
      aiContent.textContent = generateAIReadableContent(profileData);
      
      // Add breadcrumb structured data
      const breadcrumbData = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "الرئيسية",
            "item": window.location.origin
          }
        ]
      };
      
      let breadcrumbScript = document.querySelector('#breadcrumb-data');
      if (!breadcrumbScript) {
        breadcrumbScript = document.createElement('script');
        breadcrumbScript.id = 'breadcrumb-data';
        breadcrumbScript.type = 'application/ld+json';
        document.head.appendChild(breadcrumbScript);
      }
      breadcrumbScript.textContent = JSON.stringify(breadcrumbData);
    }
  }, [profileData, locale]);
};