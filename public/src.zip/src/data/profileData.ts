export interface ProfileData {
  // Personal Information
  fullName: string;
  title: string;
  email: string;
  phone?: string;
  location?: string;
  
  // Social Links
  github: string;
  linkedin: string;
  telegram: string;
  instagram?: string;
  twitter?: string;
  
  // Professional Summary
  summary: string;
  
  // Skills
  programmingLanguages: string[];
  databases: string[];
  cybersecurityTools: string[];
  backendWeb: string[];
  cloudDevOps: string[];
  versionControl: string[];
  networking: string[];
  ai: string[];
  
  // Soft Skills
  softSkills: string[];
  
  // Languages
  languages: Array<{
    name: string;
    level: string;
  }>;
  
  // Experience
  experience: Array<{
    title: string;
    company?: string;
    date: string;
    description: string[];
  }>;
  
  // Education
  education: Array<{
    degree: string;
    institution: string;
    date: string;
    gpa?: string;
  }>;
  
  // Certifications
  certifications: Array<{
    title: string;
    institution: string;
    date: string;
    credentialId?: string;
  }>;
  
  // Projects
  projects: Array<{
    title: string;
    description: string;
    technologies: string[];
    status: 'completed' | 'in-progress' | 'planned';
    duration: string;
    teamSize: number;
    githubUrl?: string;
    liveUrl?: string;
    featured?: boolean;
  }>;
  
  // SEO Data
  seo: {
    keywords: string[];
    metaDescription: string;
    ogImage?: string;
  };
}

// Default profile data - يمكن تعديل هذه البيانات بسهولة
export const defaultProfileData: ProfileData = {
  fullName: "وهيب مهيوب علي اسماعيل",
  title: "خبير في الأمن السيبراني",
email: "rhybmhywb9@gmail.com",
phone: "+967738695139",
location: "تعز، اليمن",

github: "https://github.com/waheeb71",
linkedin: "https://www.linkedin.com/in/waheeb71", // لم يتم توفير رابط LinkedIn في البيانات المرسلة
telegram: "https://t.me/WAT4F", // لم يتم توفير رابط Telegram
instagram: "https://instagram.com/wa_20_cys",
twitter: "https://x.com/wa__cys",

  summary: "متخصص أمن سيبراني ملتزم وماهر، ولديه التزام قوي بحماية الأصول الرقمية وتخفيف التهديدات السيبرانية. ذو خبرة في تقييم الثغرات، واختبار الاختراق، وتنفيذ التدابير الأمنية المتقدمة. قادر على العمل بشكل مستقل وتعاوني لضمان وضع أمني قوي والامتثال داخل البيئات سريعة الخطى. شغوف بمواكبة أحدث اتجاهات وتقنيات الأمن السيبراني لحماية البنية التحتية للمؤسسة.",
  
  programmingLanguages: ["Python", "Java", "C++", "JavaScript", "Bash", "Dart/Flutter"],
  databases: ["MySQL", "PostgreSQL", "MongoDB"],
  cybersecurityTools: ["Nmap", "Metasploit", "Wireshark", "Burp Suite", "Kali Linux"],
  backendWeb: ["Node.js", "Express.js", "Flask", "REST APIs", "Secure Coding Practices"],
  cloudDevOps: ["AWS", "Azure", "Docker", "CI/CD Fundamentals"],
  versionControl: ["Git", "GitHub", "GitLab"],
  networking: ["TCP/IP", "DNS", "DHCP", "Firewalls", "VPNs"],
  ai: ["Machine Learning", "Deep Learning", "NLP", "Computer Vision"],
  
  softSkills: [
    "القدرة على العمل تحت الضغط",
    "مهارات حل المشكلات",
    "التفكير التحليلي والانتباه للتفاصيل",
    "مهارات التواصل الفعّال والعمل الجماعي",
    "إدارة الوقت والتعلم المستمر",
    "تحمل المسؤولية"
  ],
  
  languages: [
    { name: "العربية", level: "لغة أم" },
    { name: "الإنجليزية", level: "ممتاز" }
  ],
  
  experience: [
    {
      title: "مهندس برمجيات ومتخصص في الأمن السيبراني",
      company: "شركة التقنيات المتقدمة",
      date: "2025 - حتى الآن",
      description: [
        "تصميم وتطوير حلول برمجية آمنة باستخدام Python، Node.js، و Flask",
        "إجراء اختبارات الاختراق وتقييمات الثغرات على التطبيقات والشبكات",
        "تحليل ومراقبة حركة مرور الشبكة باستخدام Wireshark وأدوات SIEM",
        "تنفيذ سياسات الأمان وتعزيز تدابير الأمن السيبراني للشركة"
      ]
    },
    {
      title: "مطور برمجيات مبتدئ",
      company: "شركة الحلول التقنية",
      date: "2023 - 2024",
      description: [
        "المساعدة في تطوير واختبار مكونات البرامج باستخدام Java و JavaScript",
        "المساهمة في تحسين أداء وأمان تطبيقات الويب",
        "العمل بمنهجيات Agile والتعاون ضمن فرق متعددة الوظائف"
      ]
    }
  ],
  
  education: [
    {
      degree: "بكالوريوس الهندسة في الأمن السيبراني",
      institution: "الجامعة الوطنية - تعز",
      date: "2025 - 2026",
      gpa: "3.8/4.0"
    },
    {
      degree: "شهادة الثانوية العامة - القسم العلمي",
      institution: " الامجاد بالمعشار ",
      date: "2022",
      gpa: "95%"
    }
  ],
  
  certifications: [
    {
      title: "Certified Ethical Hacker (CEH)",
      institution: "EC-Council",
      date: "2024",
      credentialId: "CEH-2024-001"
    },
    {
      title: "CompTIA Security+",
      institution: "CompTIA",
      date: "2024",
      credentialId: "SEC-2024-002"
    }
  ],
  
  projects: [
    {
      title: "وهيب AI برو: مساعد البرمجة الذكي",
      description: "بيئة تطوير متكاملة (IDE) متقدمة تجمع بين مدير ملفات قوي، محرر كود ذكي، ومساعد ذكاء اصطناعي مدعوم من جوجل جيميني. يهدف إلى تعزيز الإنتاجية من خلال توفير مساعدة ذكية في الكود، إدارة الملفات في الوقت الفعلي، وترمنال نظام مدمج.",
      technologies: ["Python", "PyQt6", "Google Gemini API", "File System Operations", "Subprocess"],
      status: "in-progress",
      duration: "شهرين (مستمر)",
      teamSize: 1,
      githubUrl: "https://github.com/waheeb71/AI-Waheeb-Pro",
      featured: true
    },
    {
      title: "أداة اختراق الواي فاي",
      description: "أداة اختراق الواي فاي هي أداة قوية مبنية على لغة البايثون تم تصميمها لأغراض الاختراق الأخلاقي وتحليل الشبكات. توفر واجهة سهلة الاستخدام لالتقاط المصافحات، كسر كلمات المرور، تحليل حركة المرور الشبكي، وتنفيذ هجمات متعددة على الشبكات.",
      technologies: ["Python", "BetterCAP", "Aircrack-ng", "iw", "termcolor", "subprocess", "Kali Linux"],
      status: "completed",
      duration: "3 أشهر",
      teamSize: 1,
      githubUrl: "https://github.com/waheeb71/WiFi-Hacking-Tool.git",
      featured: true
    },
    {
      title: "محلل حركة مرور الشبكة",
      description: "أداة مراقبة وتحليل حركة مرور الشبكة في الوقت الفعلي باستخدام Wireshark و Python. توفر رؤى تفصيلية حول بروتوكولات الشبكة واستخدام النطاق الترددي والتهديدات الأمنية المحتملة مع لوحات معلومات تفاعلية.",
      technologies: ["Python", "Wireshark", "Scapy", "Matplotlib", "Pandas"],
      status: "completed",
      duration: "4 أشهر",
      teamSize: 1,
      featured: false
    },
    {
      title: "تطبيق دردشة آمن",
      description: "تطوير تطبيق دردشة مشفر من طرف إلى طرف مع ميزات أمان متقدمة بما في ذلك السرية التامة للمحادثات، ومصادقة الرسائل، وبروتوكولات تبادل المفاتيح الآمنة.",
      technologies: ["Python", "Flask", "WebSocket", "Cryptography", "React Native"],
      status: "in-progress",
      duration: "5 أشهر",
      teamSize: 2,
      featured: false
    },
    {
      title: "إدارة الهوية القائمة على البلوك تشين",
      description: "تصميم نظام إدارة هوية لامركزي يستخدم تقنية البلوك تشين لتوفير التحقق من الهوية الرقمية بشكل آمن ويحفظ الخصوصية دون الاعتماد على سلطات مركزية.",
      technologies: ["Solidity", "Ethereum", "IPFS", "Node.js"],
      status: "planned",
      duration: "6 أشهر",
      teamSize: 3,
      featured: false
    },
    {
      title: "إطار عمل أمان إنترنت الأشياء (IoT)",
      description: "إنشاء إطار عمل أمان شامل لأجهزة إنترنت الأشياء يتضمن مصادقة الجهاز، وبروتوكولات الاتصال الآمنة، واكتشاف الشذوذ للحماية من الهجمات السيبرانية.",
      technologies: ["Embedded C", "MQTT", "Machine Learning", "Cloud Platforms"],
      status: "planned",
      duration: "7 أشهر",
      teamSize: 4,
      featured: false
    }
  ],
  
  seo: {
    keywords: [
      "وهيب مهيوب علي",
      "خبير أمن سيبراني",
      "مطور برمجيات",
      "اختبار الاختراق",
      "أمن الشبكات",
      "Python",
      "Cybersecurity Specialist",
      "Penetration Testing",
      "Network Security",
      "Ethical Hacking",
      "Software Developer",
      "Yemen",
      "Taiz",
      "الجامعة الوطنية تعز",
      "National University Taiz"
    ],
    metaDescription: "وهيب مهيوب علي - خبير أمن سيبراني ومطور برمجيات متخصص في اختبار الاختراق وأمن الشبكات. خبرة في Python وأدوات الأمن السيبراني المتقدمة.",
    ogImage: "/waheeb-profile-og.jpg"
  }
};

// نظام إدارة المحتوى - يمكن تعديل البيانات من هنا بسهولة
export class ProfileManager {
  private static instance: ProfileManager;
  private profileData: ProfileData;

  private constructor() {
    // تحميل البيانات من localStorage أو استخدام البيانات الافتراضية
    const savedData = localStorage.getItem('profileData');
    this.profileData = savedData ? JSON.parse(savedData) : { ...defaultProfileData };
  }

  public static getInstance(): ProfileManager {
    if (!ProfileManager.instance) {
      ProfileManager.instance = new ProfileManager();
    }
    return ProfileManager.instance;
  }

  public getProfile(): ProfileData {
    return { ...this.profileData };
  }

  public updateProfile(updates: Partial<ProfileData>): void {
    this.profileData = { ...this.profileData, ...updates };
    localStorage.setItem('profileData', JSON.stringify(this.profileData));
    
    // إشعار المكونات بالتحديث
    window.dispatchEvent(new CustomEvent('profileUpdated', { 
      detail: this.profileData 
    }));
  }

  public updatePersonalInfo(info: Partial<Pick<ProfileData, 'fullName' | 'title' | 'email' | 'phone' | 'location'>>): void {
    this.updateProfile(info);
  }

  public updateSocialLinks(links: Partial<Pick<ProfileData, 'github' | 'linkedin' | 'telegram' | 'instagram' | 'twitter'>>): void {
    this.updateProfile(links);
  }

  public updateSummary(summary: string): void {
    this.updateProfile({ summary });
  }

  public addProject(project: ProfileData['projects'][0]): void {
    const projects = [...this.profileData.projects, project];
    this.updateProfile({ projects });
  }

  public updateProject(index: number, project: Partial<ProfileData['projects'][0]>): void {
    const projects = [...this.profileData.projects];
    projects[index] = { ...projects[index], ...project };
    this.updateProfile({ projects });
  }

  public removeProject(index: number): void {
    const projects = this.profileData.projects.filter((_, i) => i !== index);
    this.updateProfile({ projects });
  }

  public addExperience(experience: ProfileData['experience'][0]): void {
    const experienceList = [...this.profileData.experience, experience];
    this.updateProfile({ experience: experienceList });
  }

  public updateExperience(index: number, experience: Partial<ProfileData['experience'][0]>): void {
    const experienceList = [...this.profileData.experience];
    experienceList[index] = { ...experienceList[index], ...experience };
    this.updateProfile({ experience: experienceList });
  }

  public addSkill(category: keyof Pick<ProfileData, 'programmingLanguages' | 'databases' | 'cybersecurityTools' | 'backendWeb' | 'cloudDevOps' | 'versionControl' | 'networking' | 'ai' | 'softSkills'>, skill: string): void {
    const skills = [...this.profileData[category] as string[], skill];
    this.updateProfile({ [category]: skills });
  }

  public removeSkill(category: keyof Pick<ProfileData, 'programmingLanguages' | 'databases' | 'cybersecurityTools' | 'backendWeb' | 'cloudDevOps' | 'versionControl' | 'networking' | 'ai' | 'softSkills'>, skillIndex: number): void {
    const skills = (this.profileData[category] as string[]).filter((_, i) => i !== skillIndex);
    this.updateProfile({ [category]: skills });
  }

  // دالة لتصدير البيانات كـ JSON
  public exportData(): string {
    return JSON.stringify(this.profileData, null, 2);
  }

  // دالة لاستيراد البيانات من JSON
  public importData(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData);
      this.profileData = { ...defaultProfileData, ...data };
      localStorage.setItem('profileData', JSON.stringify(this.profileData));
      window.dispatchEvent(new CustomEvent('profileUpdated', { 
        detail: this.profileData 
      }));
      return true;
    } catch (error) {
      console.error('Error importing data:', error);
      return false;
    }
  }

  // دالة لإعادة تعيين البيانات للقيم الافتراضية
  public resetToDefault(): void {
    this.profileData = { ...defaultProfileData };
    localStorage.setItem('profileData', JSON.stringify(this.profileData));
    window.dispatchEvent(new CustomEvent('profileUpdated', { 
      detail: this.profileData 
    }));
  }
}