import React, { useState, useEffect } from 'react';
import { ProfileManager, ProfileData } from '../data/profileData';
import { SEOHead } from './SEOHead';
import { StructuredData } from './StructuredData';

import { 
  Github, 
  Linkedin, 
  Send, 
  Instagram, 
  Twitter, 
  Mail, 
  MapPin, 
  Phone,
  ExternalLink,
  Calendar,
  Users,
  Clock,
  Award,
  GraduationCap,
  Briefcase,
  Code,
  Shield,
  Database,
  Cloud,
  Network,
  Brain,
  Globe
} from 'lucide-react';

export const SEOOptimizedCV: React.FC = () => {
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [currentLang, setCurrentLang] = useState<'ar' | 'en'>('ar');
  const profileManager = ProfileManager.getInstance();

  useEffect(() => {
    setProfileData(profileManager.getProfile());

    const handleProfileUpdate = (event: CustomEvent) => {
      setProfileData(event.detail);
    };

    window.addEventListener('profileUpdated', handleProfileUpdate as EventListener);
    return () => {
      window.removeEventListener('profileUpdated', handleProfileUpdate as EventListener);
    };
  }, []);

  useEffect(() => {
    const savedLang = localStorage.getItem('language') as 'ar' | 'en' || 'ar';
    setCurrentLang(savedLang);
    document.documentElement.setAttribute('lang', savedLang);
    document.documentElement.setAttribute('dir', savedLang === 'ar' ? 'rtl' : 'ltr');
  }, []);

  const switchLanguage = (lang: 'ar' | 'en') => {
    setCurrentLang(lang);
    localStorage.setItem('language', lang);
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
  };

  if (!profileData) return <div>Loading...</div>;

  const currentUrl = window.location.origin;
  const seoTitle = `${profileData.fullName} - ${profileData.title} | CV Portfolio`;
  
  return (
    <div className="min-h-screen" style={{
      fontFamily: '"Tajawal", sans-serif',
      backgroundColor: '#0F172A',
      color: '#94A3B8'
    }}>
      <SEOHead
        title={seoTitle}
        description={profileData.seo.metaDescription}
        keywords={profileData.seo.keywords.join(', ')}
        author={profileData.fullName}
        url={currentUrl}
        image={profileData.seo.ogImage}
        locale={currentLang}
      />
      
      <StructuredData profileData={profileData} locale={currentLang} />
     {/*<AdminPanel /> */} 

      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#1E293B] border-b border-[#334155] shadow-lg">
        <div className="max-w-7xl mx-auto px-4 md:px-10 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-[#F1F5F9]">
              {profileData.fullName}
            </h1>
            
            <nav className="hidden md:flex items-center space-x-8 space-x-reverse">
              <a href="#about" className="text-[#94A3B8] hover:text-[#0c09bc] transition-colors">
                {currentLang === 'ar' ? 'عني' : 'About'}
              </a>
              <a href="#skills" className="text-[#94A3B8] hover:text-[#0c09bc] transition-colors">
                {currentLang === 'ar' ? 'المهارات' : 'Skills'}
              </a>
              <a href="#experience" className="text-[#94A3B8] hover:text-[#0c09bc] transition-colors">
                {currentLang === 'ar' ? 'الخبرات' : 'Experience'}
              </a>
              <a href="#projects" className="text-[#94A3B8] hover:text-[#0c09bc] transition-colors">
                {currentLang === 'ar' ? 'المشاريع' : 'Projects'}
              </a>
              <a href="#contact" className="text-[#94A3B8] hover:text-[#0c09bc] transition-colors">
                {currentLang === 'ar' ? 'تواصل' : 'Contact'}
              </a>
            </nav>

            <div className="flex items-center gap-2">
              <button
                onClick={() => switchLanguage('ar')}
                className={`p-2 rounded border transition-colors ${
                  currentLang === 'ar' 
                    ? 'border-[#0c09bc] bg-[#0c09bc] text-white' 
                    : 'border-[#334155] hover:bg-[#334155]'
                }`}
              >
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Flag_of_Yemen.svg/24px-Flag_of_Yemen.svg.png" 
                  alt="العربية" 
                  className="w-6 h-4 rounded-sm object-cover" 
                />
              </button>
              <button
                onClick={() => switchLanguage('en')}
                className={`p-2 rounded border transition-colors ${
                  currentLang === 'en' 
                    ? 'border-[#0c09bc] bg-[#0c09bc] text-white' 
                    : 'border-[#334155] hover:bg-[#334155]'
                }`}
              >
                <img 
                  src="https://upload.wikimedia.org/wikipedia/en/thumb/a/a4/Flag_of_the_United_States.svg/24px-Flag_of_the_United_States.svg.png" 
                  alt="English" 
                  className="w-6 h-4 rounded-sm object-cover" 
                />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 text-center bg-gradient-to-br from-[#0F172A] to-[#1E293B]">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <img 
              src="/profile.png"
              alt={profileData.fullName}
              className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-[#0c09bc] shadow-2xl"
            />
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-[#F1F5F9] mb-4">
            {profileData.fullName}
          </h1>
          
          <h2 className="text-xl md:text-2xl text-[#0c09bc] mb-6 font-semibold">
            {profileData.title}
          </h2>
          
          <p className="text-lg text-[#94A3B8] mb-8 max-w-2xl mx-auto leading-relaxed">
            {currentLang === 'ar' ? 'متخصص شغوف بالأمن السيبراني' : 'Passionate cybersecurity specialist'}
          </p>

          <div className="flex justify-center gap-4 mb-8">
            <a href={profileData.github} target="_blank" rel="noopener noreferrer" 
               className="p-3 bg-[#334155] rounded-full hover:bg-[#0c09bc] transition-colors">
              <Github size={24} className="text-white" />
            </a>
            <a href={profileData.linkedin} target="_blank" rel="noopener noreferrer"
               className="p-3 bg-[#334155] rounded-full hover:bg-[#0c09bc] transition-colors">
              <Linkedin size={24} className="text-white" />
            </a>
            <a href={profileData.telegram} target="_blank" rel="noopener noreferrer"
               className="p-3 bg-[#334155] rounded-full hover:bg-[#0c09bc] transition-colors">
              <Send size={24} className="text-white" />
            </a>
            {profileData.instagram && (
              <a href={profileData.instagram} target="_blank" rel="noopener noreferrer"
                 className="p-3 bg-[#334155] rounded-full hover:bg-[#0c09bc] transition-colors">
                <Instagram size={24} className="text-white" />
              </a>
            )}
            {profileData.twitter && (
              <a href={profileData.twitter} target="_blank" rel="noopener noreferrer"
                 className="p-3 bg-[#334155] rounded-full hover:bg-[#0c09bc] transition-colors">
                <Twitter size={24} className="text-white" />
              </a>
            )}
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-[#64748B]">
            {profileData.email && (
              <div className="flex items-center gap-2">
                <Mail size={16} />
                <span>{profileData.email}</span>
              </div>
            )}
            {profileData.phone && (
              <div className="flex items-center gap-2">
                <Phone size={16} />
                <span>{profileData.phone}</span>
              </div>
            )}
            {profileData.location && (
              <div className="flex items-center gap-2">
                <MapPin size={16} />
                <span>{profileData.location}</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-8 text-center">
            {currentLang === 'ar' ? 'عني' : 'About Me'}
          </h2>
          <div className="bg-[#1E293B] p-8 rounded-lg border border-[#334155] shadow-lg">
            <p className="text-[#94A3B8] leading-relaxed text-lg">
              {profileData.summary}
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-16 px-4 bg-[#1E293B]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-12 text-center">
            {currentLang === 'ar' ? 'المهارات التقنية' : 'Technical Skills'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <SkillCard 
              icon={<Code size={24} />}
              title={currentLang === 'ar' ? 'لغات البرمجة' : 'Programming Languages'}
              skills={profileData.programmingLanguages}
            />
            <SkillCard 
              icon={<Database size={24} />}
              title={currentLang === 'ar' ? 'قواعد البيانات' : 'Databases'}
              skills={profileData.databases}
            />
            <SkillCard 
              icon={<Shield size={24} />}
              title={currentLang === 'ar' ? 'أدوات الأمن السيبراني' : 'Cybersecurity Tools'}
              skills={profileData.cybersecurityTools}
            />
            <SkillCard 
              icon={<Globe size={24} />}
              title={currentLang === 'ar' ? 'تطوير الواجهة الخلفية' : 'Backend Development'}
              skills={profileData.backendWeb}
            />
            <SkillCard 
              icon={<Cloud size={24} />}
              title={currentLang === 'ar' ? 'الحوسبة السحابية' : 'Cloud & DevOps'}
              skills={profileData.cloudDevOps}
            />
            <SkillCard 
              icon={<Network size={24} />}
              title={currentLang === 'ar' ? 'الشبكات' : 'Networking'}
              skills={profileData.networking}
            />
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-12 text-center">
            {currentLang === 'ar' ? 'الخبرات العملية' : 'Professional Experience'}
          </h2>
          
          <div className="space-y-8">
            {profileData.experience.map((exp, index) => (
              <div key={index} className="bg-[#1E293B] p-8 rounded-lg border border-[#334155] shadow-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-[#F1F5F9] mb-2">{exp.title}</h3>
                    {exp.company && (
                      <p className="text-[#0c09bc] font-medium">{exp.company}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[#64748B]">
                    <Calendar size={16} />
                    <span>{exp.date}</span>
                  </div>
                </div>
                <ul className="space-y-2">
                  {exp.description.map((desc, i) => (
                    <li key={i} className="text-[#94A3B8] flex items-start gap-3">
                      <span className="w-2 h-2 bg-[#0c09bc] rounded-full mt-2 flex-shrink-0"></span>
                      {desc}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-16 px-4 bg-[#1E293B]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-12 text-center">
            {currentLang === 'ar' ? 'المشاريع' : 'Projects'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {profileData.projects.map((project, index) => (
              <ProjectCard key={index} project={project} currentLang={currentLang} />
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-12 text-center">
            {currentLang === 'ar' ? 'المؤهلات العلمية' : 'Education'}
          </h2>
          
          <div className="space-y-6">
            {profileData.education.map((edu, index) => (
              <div key={index} className="bg-[#1E293B] p-6 rounded-lg border border-[#334155] shadow-lg">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-[#F1F5F9] mb-2">{edu.degree}</h3>
                    <p className="text-[#0c09bc] font-medium">{edu.institution}</p>
                    {edu.gpa && (
                      <p className="text-[#94A3B8] text-sm mt-1">
                        {currentLang === 'ar' ? 'المعدل: ' : 'GPA: '}{edu.gpa}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[#64748B]">
                    <GraduationCap size={16} />
                    <span>{edu.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 bg-[#1E293B]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-[#F1F5F9] mb-12">
            {currentLang === 'ar' ? 'للتواصل' : 'Get In Touch'}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <ContactCard 
              icon={<Mail size={24} />}
              label={currentLang === 'ar' ? 'البريد الإلكتروني' : 'Email'}
              value={profileData.email}
              href={`mailto:${profileData.email}`}
            />
            <ContactCard 
              icon={<Linkedin size={24} />}
              label="LinkedIn"
              value="https://www.linkedin.com/in/waheeb71"
              href={profileData.linkedin}
            />
            <ContactCard 
              icon={<Github size={24} />}
              label="GitHub"
              value="https://github.com/waheeb71"
              href={profileData.github}
            />
            <ContactCard 
              icon={<Send size={24} />}
              label="Telegram"
              value="@WAT4F"
              href={profileData.telegram}
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-[#334155] text-center">
        <p className="text-[#64748B]">
          © 2025 {profileData.fullName}. {currentLang === 'ar' ? 'جميع الحقوق محفوظة' : 'All rights reserved'}.
        </p>
      </footer>
    </div>
  );
};

// Helper Components
const SkillCard: React.FC<{ icon: React.ReactNode; title: string; skills: string[] }> = ({ icon, title, skills }) => (
  <div className="bg-[#334155] p-6 rounded-lg border border-[#475569] shadow-lg hover:shadow-xl transition-shadow">
    <div className="flex items-center gap-3 mb-4">
      <div className="text-[#0c09bc]">{icon}</div>
      <h3 className="text-lg font-semibold text-[#F1F5F9]">{title}</h3>
    </div>
    <div className="flex flex-wrap gap-2">
      {skills.map((skill, index) => (
        <span key={index} className="bg-[#475569] px-3 py-1 rounded-full text-sm text-[#F1F5F9]">
          {skill}
        </span>
      ))}
    </div>
  </div>
);

const ProjectCard: React.FC<{ project: ProfileData['projects'][0]; currentLang: 'ar' | 'en' }> = ({ project, currentLang }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'in-progress': return 'bg-amber-500';
      case 'planned': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    if (currentLang === 'ar') {
      switch (status) {
        case 'completed': return 'مكتمل';
        case 'in-progress': return 'قيد التنفيذ';
        case 'planned': return 'مخطط له';
        default: return status;
      }
    } else {
      switch (status) {
        case 'completed': return 'Completed';
        case 'in-progress': return 'In Progress';
        case 'planned': return 'Planned';
        default: return status;
      }
    }
  };

  return (
    <div className="bg-[#334155] p-6 rounded-lg border border-[#475569] shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-[#F1F5F9] leading-tight">{project.title}</h3>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${getStatusColor(project.status)}`}>
          {getStatusText(project.status)}
        </span>
      </div>
      
      <p className="text-[#94A3B8] text-sm mb-4 leading-relaxed">{project.description}</p>
      
      <div className="mb-4">
        <h4 className="text-sm font-semibold text-[#F1F5F9] mb-2">
          {currentLang === 'ar' ? 'التقنيات' : 'Technologies'}
        </h4>
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech, index) => (
            <span key={index} className="bg-[#475569] px-2 py-1 rounded-md text-xs font-medium text-[#F1F5F9]">
              {tech}
            </span>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-[#64748B] mb-6">
        <div className="flex items-center gap-1">
          <Clock size={14} />
          <span>{project.duration}</span>
        </div>
        <div className="flex items-center gap-1">
          <Users size={14} />
          <span>{project.teamSize} {currentLang === 'ar' ? 'مطور' : 'developer'}{project.teamSize > 1 ? 's' : ''}</span>
        </div>
      </div>

      <div className="flex gap-3">
        {project.githubUrl && (
          <a 
            href={project.githubUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex-1 inline-flex items-center justify-center rounded-md py-2 text-sm font-medium transition-colors bg-[#0c09bc] text-white hover:bg-[#0F766E]"
          >
            <ExternalLink size={16} className="mr-2" />
            {currentLang === 'ar' ? 'عرض المشروع' : 'View Project'}
          </a>
        )}
      </div>
    </div>
  );
};

const ContactCard: React.FC<{ icon: React.ReactNode; label: string; value: string; href: string }> = ({ icon, label, value, href }) => (
  <a 
    href={href} 
    target="_blank" 
    rel="noopener noreferrer"
    className="bg-[#334155] p-6 rounded-lg border border-[#475569] shadow-lg hover:shadow-xl transition-all hover:bg-[#0c09bc] group"
  >
    <div className="text-[#0c09bc] group-hover:text-white mb-3 flex justify-center">{icon}</div>
    <h3 className="text-[#F1F5F9] font-semibold mb-2">{label}</h3>
    <p className="text-[#94A3B8] text-sm group-hover:text-white">{value}</p>
  </a>
);