import React from 'react';

interface SEOHeadProps {
  title: string;
  description: string;
  keywords: string;
  author: string;
  url: string;
  image?: string;
  type?: string;
  locale: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  keywords,
  author,
  url,
  image = '/profile.png',
  type = 'website',
  locale
}) => {
  React.useEffect(() => {
    // Update document title
    document.title = title;
    
    // Update meta tags
    const updateMeta = (name: string, content: string, property?: boolean) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let meta = document.querySelector(selector) as HTMLMetaElement;
      if (!meta) {
        meta = document.createElement('meta');
        if (property) {
          meta.setAttribute('property', name);
        } else {
          meta.setAttribute('name', name);
        }
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Basic SEO meta tags
    updateMeta('description', description);
    updateMeta('keywords', keywords);
    updateMeta('author', author);
    updateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    updateMeta('googlebot', 'index, follow');
    updateMeta('bingbot', 'index, follow');
    updateMeta('viewport', 'width=device-width, initial-scale=1.0');
    
    // Open Graph meta tags
    updateMeta('og:title', title, true);
    updateMeta('og:description', description, true);
    updateMeta('og:type', type, true);
    updateMeta('og:url', url, true);
    updateMeta('og:image', image, true);
    updateMeta('og:locale', locale, true);
    updateMeta('og:site_name', author, true);
    
    // Twitter Card meta tags
    updateMeta('twitter:card', 'summary_large_image');
    updateMeta('twitter:title', title);
    updateMeta('twitter:description', description);
    updateMeta('twitter:image', image);
    updateMeta('twitter:creator', '@wa__cys');
    
    // Additional SEO meta tags
    updateMeta('theme-color', '#0c09bc');
    updateMeta('msapplication-TileColor', '#0c09bc');
    updateMeta('application-name', author);
    
    // Structured data for better AI understanding
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Person",
      "name": author,
      "jobTitle": locale === 'ar' ? "خبير في الأمن السيبراني" : "Cybersecurity Specialist",
      "description": description,
      "url": url,
      "image": image,
      "sameAs": [
        "https://github.com/waheeb71",
        "https://www.linkedin.com/in/waheeb71",
        "https://t.me/WAT4F"
      ],
      "knowsAbout": [
        "Cybersecurity",
        "Penetration Testing",
        "Python Programming",
        "Network Security",
        "Vulnerability Assessment",
        "Ethical Hacking",
        "Software Development",
        "AI and Machine Learning"
      ],
      "alumniOf": {
        "@type": "EducationalOrganization",
        "name": locale === 'ar' ? "الجامعة الوطنية - تعز" : "National University - Taiz"
      },
      "hasOccupation": {
        "@type": "Occupation",
        "name": locale === 'ar' ? "مهندس برمجيات ومتخصص في الأمن السيبراني" : "Software Engineer & Cybersecurity Specialist"
      }
    };

    // Update or create structured data script
    let structuredDataScript = document.querySelector('#structured-data') as HTMLScriptElement;
    if (!structuredDataScript) {
      structuredDataScript = document.createElement('script');
      structuredDataScript.id = 'structured-data';
      structuredDataScript.type = 'application/ld+json';
      document.head.appendChild(structuredDataScript);
    }
    structuredDataScript.textContent = JSON.stringify(structuredData);

    // Add canonical URL
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = url;

    // Add hreflang tags for multilingual support
    const updateHreflang = (lang: string, href: string) => {
      let hreflang = document.querySelector(`link[hreflang="${lang}"]`) as HTMLLinkElement;
      if (!hreflang) {
        hreflang = document.createElement('link');
        hreflang.rel = 'alternate';
        hreflang.setAttribute('hreflang', lang);
        document.head.appendChild(hreflang);
      }
      hreflang.href = href;
    };

    updateHreflang('ar', url + '?lang=ar');
    updateHreflang('en', url + '?lang=en');
    updateHreflang('x-default', url);

  }, [title, description, keywords, author, url, image, type, locale]);

  return null;
};