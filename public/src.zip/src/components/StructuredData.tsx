import React from 'react';
import { ProfileData } from '../data/profileData';

interface StructuredDataProps {
  profileData: ProfileData;
  locale: string;
}

export const StructuredData: React.FC<StructuredDataProps> = ({ profileData, locale }) => {
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Person",
        "@id": `${window.location.origin}/#person`,
        "name": profileData.fullName,
        "alternateName": locale === 'ar' ? "وهيب مهيوب علي" : "Waheeb Mahyoob Ali",
        "jobTitle": profileData.title,
        "description": profileData.summary,
        "url": window.location.origin,
        "image": {
          "@type": "ImageObject",
          "url": profileData.seo.ogImage || `${window.location.origin}/profile.png`,
          "width": 400,
          "height": 400
        },
        "sameAs": [
          profileData.github,
          profileData.linkedin,
          profileData.telegram,
          ...(profileData.instagram ? [profileData.instagram] : []),
          ...(profileData.twitter ? [profileData.twitter] : [])
        ],
        "email": profileData.email,
        "telephone": profileData.phone,
        "address": {
          "@type": "PostalAddress",
          "addressLocality": profileData.location
        },
        "knowsAbout": [
          ...profileData.programmingLanguages,
          ...profileData.cybersecurityTools,
          ...profileData.backendWeb,
          "Cybersecurity",
          "Penetration Testing",
          "Network Security",
          "Ethical Hacking",
          "Software Development"
        ],
        "hasOccupation": {
          "@type": "Occupation",
          "name": profileData.experience[0]?.title || profileData.title,
          "occupationLocation": {
            "@type": "Place",
            "name": profileData.location
          },
          "skills": profileData.seo.keywords.join(", ")
        },
        "alumniOf": profileData.education.map(edu => ({
          "@type": "EducationalOrganization",
          "name": edu.institution,
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "تعز، اليمن"
          }
        })),
        "hasCredential": profileData.certifications.map(cert => ({
          "@type": "EducationalOccupationalCredential",
          "name": cert.title,
          "credentialCategory": "certification",
          "recognizedBy": {
            "@type": "Organization",
            "name": cert.institution
          },
          "dateCreated": cert.date
        }))
      },
      {
        "@type": "WebSite",
        "@id": `${window.location.origin}/#website`,
        "url": window.location.origin,
        "name": `${profileData.fullName} - ${profileData.title}`,
        "description": profileData.seo.metaDescription,
        "publisher": {
          "@id": `${window.location.origin}/#person`
        },
        "inLanguage": [
          {
            "@type": "Language",
            "name": "Arabic",
            "alternateName": "ar"
          },
          {
            "@type": "Language", 
            "name": "English",
            "alternateName": "en"
          }
        ],
        "potentialAction": {
          "@type": "SearchAction",
          "target": {
            "@type": "EntryPoint",
            "urlTemplate": `${window.location.origin}?q={search_term_string}`
          },
          "query-input": "required name=search_term_string"
        }
      },
      {
        "@type": "WebPage",
        "@id": `${window.location.origin}/#webpage`,
        "url": window.location.href,
        "name": document.title,
        "isPartOf": {
          "@id": `${window.location.origin}/#website`
        },
        "about": {
          "@id": `${window.location.origin}/#person`
        },
        "description": profileData.seo.metaDescription,
        "breadcrumb": {
          "@type": "BreadcrumbList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "الرئيسية",
              "item": window.location.origin
            }
          ]
        }
      },
      // Add projects as CreativeWork
      ...profileData.projects.map((project, index) => ({
        "@type": "CreativeWork",
        "@id": `${window.location.origin}/#project-${index}`,
        "name": project.title,
        "description": project.description,
        "creator": {
          "@id": `${window.location.origin}/#person`
        },
        "dateCreated": "2024",
        "programmingLanguage": project.technologies,
        "url": project.githubUrl || project.liveUrl,
        "workExample": {
          "@type": "SoftwareApplication",
          "name": project.title,
          "applicationCategory": "DeveloperApplication",
          "operatingSystem": "Cross-platform"
        }
      }))
    ]
  };

  React.useEffect(() => {
    let script = document.querySelector('#structured-data-json') as HTMLScriptElement;
    if (!script) {
      script = document.createElement('script');
      script.id = 'structured-data-json';
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData, null, 2);
  }, [profileData, locale]);

  return null;
};