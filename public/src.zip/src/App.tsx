import React from 'react';
import { SEOOptimizedCV } from './components/SEOOptimizedCV';

function App() {
  return (
    <SEOOptimizedCV />
  );
}

export default App;
